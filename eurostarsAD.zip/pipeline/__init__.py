"""Eurostars pipeline package."""
